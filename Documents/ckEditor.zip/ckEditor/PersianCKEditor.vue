<template>
  <div height="100%" style="height: 100%!important;">
    <div
        :style="errorMessages && errorMessages[0] ? 'border: 1px solid #dd2c00!important;border-radius: 4px;height: calc( 100% - 24px);' : 'border: 1px solid #b5b5b5!important;border-radius: 4px;height: calc( 100% - 24px);'"
    >
      <h4 class="pa-2" style="height: 20% !important;">{{ title }}</h4>
      <div style="height: 80% !important;">
        <client-only placeholder="loading...">
          <ckEditorNuxt
              v-model="model"
              :config="editorConfig"
              :value_init="value_init"
              :disabled="disabled"
              v-on="$listeners"
          />
        </client-only>
      </div>
    </div>
    <div class="error--text" style="height: 24px;">{{ errorMessages ? errorMessages[0] : null }}</div>
  </div>
</template>

<script>
import ckEditorNuxt from '@/components/ckEditor/ckEditorNuxt'

if (process.client) {
  require('@/components/ckEditor/falang.js')
}

export default {
  name: 'PersianCKEditor',
  components: {
    ckEditorNuxt
  },
  props: ['title', 'value_init', 'value', 'errorMessages', 'disabled'],
  data() {
    return {
      editorConfig: {
        placeholder: 'اینجا بنویسید ...',
        removePlugins: ['Title'],
        heading: {
          options: [
            {
              model: 'paragraph',
              title: 'پاراگراف',
              class: 'ck-heading_paragraph'
            },
            {
              model: 'heading1',
              view: 'h1',
              title: 'سربرگ نوع ۱',
              class: 'ck-heading_heading1'
            },
            {
              model: 'heading2',
              view: 'h2',
              title: 'سربرگ نوع ۲',
              class: 'ck-heading_heading2'
            },
            {
              model: 'heading3',
              view: 'h3',
              title: 'سربرگ نوع ۳',
              class: 'ck-heading_heading3'
            },
            {
              model: 'heading4',
              view: 'h4',
              title: 'سربرگ نوع 4',
              class: 'ck-heading_heading4'
            }
          ]
        },
        title: {
          view: ''
        },
        language: {
          ui: 'fa',
          content: 'fa',
          defaultLanguage: 'fa'
        }
      },
      model: this.value
    }
  },
  watch: {
    model(currentValue) {
      this.$emit('input', currentValue)
    },
    value(currentValue) {
      this.model = this.value
    },
  },
  methods: {
    save() {
      alert(this.contentHolder)
    }
  }
}
</script>

<style>
.ck-body-wrapper * {
  z-index: 400 !important;
}


.ck-rounded-corners {
  height: 80% !important;
  max-height: 80% !important;
}

.ck-editor__main {
  height: 100% !important;
  max-height: 100% !important;
}

.ck-editor__editable {
  padding-right: 30px !important;
  height: 100% !important;
  max-height: 100% !important;
  min-height: 100% !important;
  overflow: scroll;
}
</style>

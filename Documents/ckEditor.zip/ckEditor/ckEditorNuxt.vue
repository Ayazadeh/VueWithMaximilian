<template>
  <ckeditor
    v-model="model"
    :editor="editor"
    :config="config"
    :tag-name="tagName"
    :disabled="disabled"
    @input="event => $emit('input', event)"
    v-on="$listeners"
  />
</template>

<script>

let Classiceditor
let CKEditor

if (process.client) {
  Classiceditor = require('~/plugins/ckeditor5-build-inline')
  CKEditor = require('@ckeditor/ckeditor5-vue2')
} else {
  CKEditor = {component: {template: '<div></div>'}}
}


export default {
  name: "CkEditorNuxt",
  components: {
    ckeditor: CKEditor.component
  },
  props: [
    'value_init',
    'tagName',
    'disabled',
    'uploadUrl',
    'config',
    'value',
    // editor: Function
  ],
  data() {
    return {
      editor: Classiceditor,
      model: this.value
    }
  },
  watch: {
    value(currentValue) {
      this.model = this.value
    },
  }
}
</script>

<style scoped>

</style>
